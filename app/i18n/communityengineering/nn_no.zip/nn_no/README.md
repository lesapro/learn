# language-nn_NO
Language package for nn_NO. 
